const sharp = require('sharp');

module.exports = function(format, width, height) {
    
}